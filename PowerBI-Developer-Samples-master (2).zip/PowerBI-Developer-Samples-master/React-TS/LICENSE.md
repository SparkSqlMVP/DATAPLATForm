|NPM Package        | License                                                                                           |
|:---------------   |:-------------------------------------------------------------------------------------------------:|
|@types/react       |[MIT](https://github.com/DefinitelyTyped/DefinitelyTyped/blob/master/LICENSE)                      |
|@types/react-dom   |[MIT](https://github.com/DefinitelyTyped/DefinitelyTyped/blob/master/LICENSE)                      |
|@types/bluebird    |[MIT](https://github.com/DefinitelyTyped/DefinitelyTyped/blob/master/LICENSE)                      |
|bluebird           |[MIT](https://github.com/petkaantonov/bluebird/blob/master/LICENSE)                      |
|eslint             |[MIT](https://github.com/eslint/eslint/blob/master/LICENSE)                                        |
|eslint-plugin-react|[MIT](https://github.com/yannickcr/eslint-plugin-react/blob/master/LICENSE)                        |
|msal               |[MIT](https://github.com/AzureAD/microsoft-authentication-library-for-js#readme)                   |
|powerbi-client     |[MIT](https://github.com/microsoft/PowerBI-JavaScript/blob/master/LICENSE.txt)                     |
|react              |[MIT](https://github.com/facebook/react/blob/master/LICENSE)                                       |
|react-app-polyfill |[MIT](https://github.com/facebook/create-react-app/blob/master/packages/react-app-polyfill/LICENSE)|
|react-scripts      |[MIT](https://github.com/facebook/create-react-app/blob/master/packages/react-scripts/LICENSE)     |
|typescript         |[Apache-2.0](https://github.com/microsoft/TypeScript/blob/master/LICENSE.txt)                      |