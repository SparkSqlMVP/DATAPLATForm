# Links to licenses for the 3rd party softwares used:
|Software|License|
|--|--|
|Spring framework|[Apache License 2.0](https://github.com/spring-projects/spring-framework/blob/master/LICENSE.txt)|
|Apache tomcat|[Apache License 2.0](http://www.apache.org/licenses/LICENSE-2.0)|
|SLF4J|[MIT](http://www.slf4j.org/license.html)|
|org.json|[MIT](https://github.com/stleary/JSON-java/blob/master/LICENSE)|
|Bootstrap|[MIT](https://github.com/twbs/bootstrap/blob/v4.0.0/LICENSE)|
|jQuery|[MIT](https://jquery.org/license/)|